/*
Leer valores hasta que se introduzca un cero (0)
El usuario puede introducir valores positivos y negativos
Encontrar el máximo de los elementos que se introdujeron
Analizar cómo cambia el programa para hallar el mínimo

*/
import "./styles.css";

//Pido al usuario que ingrese un número
let userNumbers: number = Number(prompt("Ingrese un número"));
// Almaceno en una variable el número ingresado
let maxNum: number = userNumbers;

//Mientras el número ingresado por el usuario sea distinto de 0
while (userNumbers !== 0) {
	//Pregunto si el número ingresado es mayor al almacenado en la variable maxNum
	if (userNumbers > maxNum) {
		//Si es true almaceno el nuevo número en la variable maxNum
		maxNum = userNumbers;
	}
	//Pido al usuario otro número
	userNumbers = Number(prompt("Ingrese un número"));
}
//Muestro en consola el número máximo guardado en la variable maxNum
console.log(maxNum);
